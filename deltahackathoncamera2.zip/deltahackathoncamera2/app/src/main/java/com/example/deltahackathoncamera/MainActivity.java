package com.example.deltahackathoncamera;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static Bitmap bitmap;
    Camera camera;
    imagesurfaceview sv;
    FrameLayout fl;
    ImageView iv;
    RecyclerView r;
    ImageButton capture;
    recentpicsadapter adapter;
    List<String> listOfAllImages;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Uri uri = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        listOfAllImages=new ArrayList<>();
        String absolutePathOfImage;
        String[] projection = {MediaStore.MediaColumns.DATA};
        Cursor cursor = getContentResolver().query(uri, projection, null, null, null);
        while (cursor.moveToNext()) {
            absolutePathOfImage = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA));
            listOfAllImages.add(absolutePathOfImage);
        }
        fl=findViewById(R.id.camera_preview);
        iv=findViewById(R.id.captured_image);
        capture=findViewById(R.id.button);
        camera= Camera.open();
        camera.setDisplayOrientation(90);
        sv=new imagesurfaceview(this,camera);
        fl.addView(sv);
        capture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                camera.takePicture(null,null,takepicture);
            }
        });
        r=findViewById(R.id.recentpics);
        adapter=new recentpicsadapter(this,listOfAllImages);
        RecyclerView.LayoutManager lm=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        r.setLayoutManager(lm);
        r.setAdapter(adapter);
    }
    Camera.PictureCallback takepicture=new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
            Intent intent=new Intent(getApplicationContext(),Main2Activity.class);
            startActivity(intent);
        }
    };

    public Bitmap getBitmap() {
        return bitmap;
    }
}

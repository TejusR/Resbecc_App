package com.example.deltahackathoncamera;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.graphics.Matrix;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.theartofdev.edmodo.cropper.CropImage;

import java.io.ByteArrayOutputStream;

public class Main2Activity extends AppCompatActivity {
    ImageView iv;
    Activity a;
    ImageButton crop;
    int WRITE_REQUEST_CODE;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        a=this;
        Matrix matrix = new Matrix();
        matrix.setRotate(90);
        iv=findViewById(R.id.imageView2);
        iv.setImageBitmap(Bitmap.createBitmap(MainActivity.bitmap,0,0,MainActivity.bitmap.getWidth(),MainActivity.bitmap.getHeight(),matrix,true));
        crop=findViewById(R.id.cropbutton);
        crop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                requestPermissions(permissions, WRITE_REQUEST_CODE);
                Intent CropIntent = new Intent("com.android.camera.action.CROP");
                CropIntent.setDataAndType(getImageUri(getApplicationContext(),MainActivity.bitmap), "image/*");
                CropIntent.putExtra("crop", "true");
                CropIntent.putExtra("outputX", 180);
                CropIntent.putExtra("outputY", 180);
                CropIntent.putExtra("aspectX", 3);
                CropIntent.putExtra("aspectY", 4);
                CropIntent.putExtra("scaleUpIfNeeded", true);
                CropIntent.putExtra("return-data", true);

                startActivityForResult(CropIntent, 1);*/
                CropImage.activity(getImageUri(getApplicationContext(),MainActivity.bitmap))
                        .start(a);
            }
        });
    }
    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }
}

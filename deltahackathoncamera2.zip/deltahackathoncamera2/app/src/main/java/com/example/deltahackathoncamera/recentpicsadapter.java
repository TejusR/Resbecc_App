package com.example.deltahackathoncamera;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class recentpicsadapter extends RecyclerView.Adapter<recentpicsadapter.viewholder>{
    Context context;
    List<String> path;

    public recentpicsadapter(Context context, List<String> path) {
        this.context = context;
        this.path = path;
    }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(context).inflate(R.layout.piclist,null);
        viewholder holder=new viewholder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int i) {
        Bitmap myBitmap = BitmapFactory.decodeFile(path.get(i));
        holder.pic.setImageBitmap(myBitmap);
    }

    @Override
    public int getItemCount() {
        return path.size();
    }

    public class viewholder extends RecyclerView.ViewHolder{
        ImageView pic;
        public viewholder(@NonNull View itemView) {
            super(itemView);
            pic=itemView.findViewById(R.id.imageView);
        }
    }
}
